<template>
  <div class="listSearch listSearchAppeal">
    <div class="search-box flex-middle">
      <input type="text"/>
      <button type="button"><i class="iconfont icon-search"></i></button>
    </div>
  </div>
</template>


<script >
export default {
  components: {
  },
  props: {
  },
  data: function() {
    return {
    }
  },
  computed: {
  },
  watch: {
  },
  methods: {
  },
  created: function(){
  },
  mounted: function(){
  }
}
</script>


<style lang="scss" scoped>
</style>