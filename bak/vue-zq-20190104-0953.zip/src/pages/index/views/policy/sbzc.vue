<template>
  <div class="sbzc">
    <list-fcsb :paginationShow="true"></list-fcsb>
  </div>
</template>


<script>
import ListFcsb from '../../../../components/ListFcsb'

export default {
  components: {
    'list-fcsb': ListFcsb,
  },
  props: {
  },
  data: function() {
    return {
    }
  },
  computed: {
  },
  watch: {
  },
  methods: {
  },
  created: function(){
  },
  mounted: function(){
  }
}
</script>


<style lang="scss" scoped>
</style>