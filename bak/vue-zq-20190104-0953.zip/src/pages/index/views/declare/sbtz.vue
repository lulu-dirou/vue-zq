<template>
  <div class="sbtz">
    <list-sbtz :paginationShow="true"></list-sbtz>
  </div>
</template>


<script>
import ListSbtz from '../../../../components/ListSbtz'

export default {
  components: {
    'list-sbtz': ListSbtz,
  },
  props: {
  },
  data: function() {
    return {
    }
  },
  computed: {
  },
  watch: {
  },
  methods: {
  },
  created: function(){
  },
  mounted: function(){
  }
}
</script>


<style lang="scss" scoped>
</style>